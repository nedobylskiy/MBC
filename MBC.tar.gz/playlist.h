#ifndef PLAYLIST_H
#define PLAYLIST_H

#include <QWidget>
#include <QMenu>
#include <QDateTime>

struct song
{
  int duration;
  QString path,name;
};


namespace Ui {
class PlayList;
}

class PlayList : public QWidget
{
    Q_OBJECT
    
public:
    explicit PlayList(QWidget *parent = 0);
    ~PlayList();
    int length;
    int spos;
    QString file;

    void AddItem(QString name,QString path, int duration);
    int count();
    void DeleteTopItem();
    song GetTopItem();
    void Mirror(); //not used
    void clear();
    void DeleteSelected();
    void SetLen(int dlen,int dpos);
    void AssignToFile(QString filef);
    void SaveList();
    void LoadList();


private:
    Ui::PlayList *ui;
     QString Sec22TimeStr(int sec);
     QMenu *menu;
     QString ExtractPParam(QString content,QString key);
     QString AddPParam(QString key,QString value);
private slots:
     void MenuDelete();
     void MenuClear();
     void MenuRun(const QPoint & pos);
     void MenuToTop();
     void UpdateTimer();
signals:
     void OnTimerTick();
};

#endif // PLAYLIST_H

#include <QtGui/QApplication>
#include "mbcwindow.h"
#include "bass.h"

int main(int argc, char *argv[])
{
    if(!BASS_Init(-1, 44100, 0,0, NULL))
    {
        //cout<< "  *ERROR: Can't init BASS\n Error " << BASS_ErrorGetCode();
        return 1;
    }

    QApplication a(argc, argv);
    MBCWindow w;
    w.show();
    
    return a.exec();
}

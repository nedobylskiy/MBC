#include "playlist.h"
#include "ui_playlist.h"
#include <QMessageBox>
#include <QMenu>
#include <QTimer>
#include <QDateTime>
#include <QFile>
#include <QShortcut>

QString PlayList::Sec22TimeStr(int sec)
{
QString resulti;
int seconds = sec % 60;
int minutes = (sec - seconds) / 60;
//char TimeString[20];

if (seconds <10) resulti.sprintf( "%d:0%d", minutes,seconds);
else
resulti.sprintf( "%d:%d", minutes,seconds);

//resulti.append(TimeString);


return resulti;
}


QString PlayList::ExtractPParam(QString content,QString key) //
{
    QString argpars,tempp;
    tempp="<!--!"+key+"!{";
    if(content.contains(tempp))
    {
    argpars=content;
    int indof = argpars.indexOf(tempp);
    argpars.remove(0,indof);
    argpars.remove(0,tempp.length());
    argpars.remove(argpars.indexOf("}-->"),argpars.length());
    return argpars;
    }
    else
        return "";
}

QString PlayList::AddPParam(QString key,QString value) //
{
    return "<!--!"+key+"!{"+value+"}-->";
}


PlayList::PlayList(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::PlayList)
{
    ui->setupUi(this);


length=0;
spos=0;

    QAction *a;
    QShortcut *shortcut;

    a = new QAction(tr("Move To Top"), this);
    connect(a, SIGNAL(triggered()), this, SLOT(MenuToTop()));
  // ui->treeWidget->addAction(a);


   // menu = new QMenu("Playlist");



  // shortcut = new QShortcut(QKeySequence(tr("Delete")), ui->treeWidget);

    a = new QAction(tr("Delete"), this);
   // a->setShortcut(QKeySequence(tr("Delete")));
    connect(a, SIGNAL(triggered()), this, SLOT(MenuDelete()));
   // menu->addAction(a);
 ui->treeWidget->addAction(a);



    a = new QAction(tr("Clear"), this);
    connect(a, SIGNAL(triggered()), this, SLOT(MenuClear()));
 ui->treeWidget->addAction(a);



 ui->treeWidget->setContextMenuPolicy(Qt::ActionsContextMenu);
   // connect(ui->treeWidget, SIGNAL(customContextMenuRequested(const QPoint &)),this, SLOT(MenuRun(const QPoint &)));

clear();

 ui->treeWidget->setColumnWidth(1,300);
 ui->treeWidget->setColumnWidth(2,80);
 ui->treeWidget->setColumnWidth(4,0);

QTimer *updatetmr = new QTimer(this);
 connect(updatetmr, SIGNAL(timeout()), SLOT(UpdateTimer()));
 updatetmr->start(1000);

}

void PlayList::AddItem(QString name,QString path, int duration)
{
    QTreeWidgetItem *topLevelItem=new QTreeWidgetItem(ui->treeWidget);
    topLevelItem->setText(0,"00:00:00");
    topLevelItem->setText(1,name);

    if(duration>0)
        topLevelItem->setText(2,Sec22TimeStr(duration));
    else
        topLevelItem->setText(2,"Radio");

    topLevelItem->setText(3,path);
    topLevelItem->setText(4,QString::number(duration));

    topLevelItem->setFlags(topLevelItem->flags() & ~Qt::ItemIsDropEnabled);
    //topLevelItem->setFlags(topLevelItem->flags() & Qt::Item);
    ui->treeWidget->addTopLevelItem(topLevelItem);
}


int PlayList::count()
{
    int i=0;
     QTreeWidgetItemIterator it(ui->treeWidget);
         while (*it)
         {
             i++;
             ++it;
         }

return i;
}

void PlayList::DeleteTopItem()
{
 QTreeWidgetItemIterator it(ui->treeWidget);
 delete (*it);
}


song PlayList::GetTopItem()
{
song so;

QTreeWidgetItemIterator it(ui->treeWidget);
so.name = (*it)->text(1);
so.path = (*it)->text(3);
so.duration = (*it)->text(4).toInt();


return so;
}


void PlayList::Mirror()
{
int i=count(),z=0;
QTreeWidgetItemIterator it(ui->treeWidget);
        while (*it)
        {

            ui->treeWidget->addTopLevelItem((*it));
            delete (*it);
            if(z==i) break;

            ++it;
            z++;
        }
}

void PlayList::clear()
{
    ui->treeWidget->clear();
}


void PlayList::DeleteSelected()
{

    QList<QTreeWidgetItem*> selectedItems(ui->treeWidget->selectedItems());
    foreach ( QTreeWidgetItem * item, selectedItems )
        delete item;
}
void PlayList::MenuDelete()
{
    DeleteSelected();
}

void PlayList::MenuClear()
{
    clear();
}

void PlayList::MenuToTop()
{
    QTreeWidgetItem*i;
    QList<QTreeWidgetItem*> selectedItems(ui->treeWidget->selectedItems());
    foreach ( QTreeWidgetItem * item, selectedItems )
       {
        //ui->treeWidget->insertTopLevelItem(0,item);
        //ui->treeWidget->
        //ui->treeWidget->insertTopLevelItem();
        i=item;
        //ui->treeWidget->removeItemWidget(item,0);
        //delete item;
        ui->treeWidget->insertTopLevelItem(1,item);
       }


}

void PlayList::MenuRun(const QPoint &pos)
{
menu->move(pos);
menu->show();
}

void PlayList::UpdateTimer()
{
    if (length<1)
    {
        length=0;
        spos=0;
    }

    qint64 tim=QDateTime::currentMSecsSinceEpoch()+((length-spos)*1000);

    //mlen++;

   // QMessageBox::about(NULL,"asd",QString::number((spos))+" "+QString::number((length)));

    QTreeWidgetItemIterator it(ui->treeWidget);
            while (*it)
            {
                (*it)->setFlags((*it)->flags() & ~Qt::ItemIsDropEnabled);

                //QTreeWidgetItem *s;
                (*it)->setText(0,QDateTime::fromMSecsSinceEpoch(tim).toString("hh:mm:ss"));
                tim=tim+((*it)->text(4).toInt()*1000);


                ++it;
            }


emit OnTimerTick();
}


void PlayList::SetLen(int dlen,int dpos)
{
length=dlen;
spos=dpos;
}


void PlayList::AssignToFile(QString filef)
{
file = filef;
}


void PlayList::SaveList()
{
    if(file.length()>0)
    {
    QFile fil(file);

    if (!fil.open(QIODevice::WriteOnly | QIODevice::Text))
             return;
    fil.write(AddPParam("count",QString::number(count())).toAscii());

    int i=0;



    QTreeWidgetItemIterator it(ui->treeWidget);
            while (*it)
            {
                (*it)->setFlags((*it)->flags() & ~Qt::ItemIsDropEnabled);
                        fil.write(AddPParam(QString::number(i)+"name",(*it)->text(1)).toAscii());
                        fil.write(AddPParam(QString::number(i)+"path",(*it)->text(3)).toAscii());

                ++it;
                i++;
            }


    fil.close();
    }
}
void PlayList::LoadList()
{

}

PlayList::~PlayList()
{
    delete ui;
}


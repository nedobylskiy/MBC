#ifndef MBCWINDOW_H
#define MBCWINDOW_H

#include <QMainWindow>
#include "bass.h"
#include "bassmix.h"
#include <QSlider>
#include <QLabel>
#include <QSplitter>
#include "player2.h"
#include "playlist.h"
#include "library.h"
#include "inputsystem.h"
#include "encoderslist.h"
#include "configure.h"

namespace Ui {
class MBCWindow;
}

class MBCWindow : public QMainWindow
{
    Q_OBJECT
    
public:
    explicit MBCWindow(QWidget *parent = 0);
    ~MBCWindow();

    bool playing;
    QString ExtractTags(QString file);
    HSTREAM main;
    int GetPlayerActive();
    void Next();
    void Play();
    void Stop();

    void SetUpTransition();

    Player2 *player1;
    Player2 *player2;
    PlayList*playlist;
    Library*showlist;
    Library *library;
    QSplitter *splitter;
    InputSystem*micpanel;
    EncodersList *enclist;
    int encicons;
    //bool encerr;

    Configure*config;



    
private:
    Ui::MBCWindow *ui;
    QSlider *vol;
    QLabel *time;
    QDateTime *tim;
    private slots:
    void TestButton();
    void PlaybackEnded();
    void NextButton();
    void PlayButton();
    void StopButton();
    void MainVol(int vol);
    void SpOrientation(Qt::Orientation orientation );
    void PlayerTimerTick();
    void PlaylistTimerTick();




};

#endif // MBCWINDOW_H
